package jto.processing.sketch.mapper;

public class ControlP5MissingException extends RuntimeException {
    private static final long serialVersionUID = 4902744341957494805L;
}
